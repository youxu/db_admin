-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2012 年 12 月 13 日 09:48
-- 服务器版本: 5.1.41
-- PHP 版本: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `cms`
--

-- --------------------------------------------------------

--
-- 表的结构 `captcha`
--

DROP TABLE IF EXISTS `captcha`;
CREATE TABLE IF NOT EXISTS `captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL AUTO_INCREMENT,
  `captcha_time` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `word` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`captcha_id`),
  KEY `word` (`word`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=86 ;

--
-- 转存表中的数据 `captcha`
--

INSERT INTO `captcha` (`captcha_id`, `captcha_time`, `ip_address`, `word`) VALUES
(85, 1355319778, '127.0.0.1', '4075');

-- --------------------------------------------------------

--
-- 表的结构 `model`
--

DROP TABLE IF EXISTS `model`;
CREATE TABLE IF NOT EXISTS `model` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `model` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `is_del` tinyint(2) NOT NULL DEFAULT '1',
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块表' AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `model`
--

INSERT INTO `model` (`id`, `name`, `model`, `status`, `is_del`, `time`) VALUES
(1, '模块管理', 'mod', 1, 1, '2012-12-07 21:30:15'),
(2, '人员管理', 'user', 1, 1, '2012-12-07 21:40:06'),
(3, '新闻分类', 'newsclass', 1, 1, '2012-12-09 14:06:23'),
(4, '新闻', 'news', 1, 1, '2012-12-09 14:11:06');

-- --------------------------------------------------------

--
-- 表的结构 `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL COMMENT '标题',
  `cid` int(255) NOT NULL COMMENT '分类id',
  `creat_time` datetime NOT NULL COMMENT '创建时间',
  `img_url` varchar(100) NOT NULL COMMENT '首页缩略图',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `is_del` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否删除',
  `is_top` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='新闻表' AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `news`
--


-- --------------------------------------------------------

--
-- 表的结构 `newsclass`
--

DROP TABLE IF EXISTS `newsclass`;
CREATE TABLE IF NOT EXISTS `newsclass` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `pid` int(255) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `is_del` tinyint(2) NOT NULL DEFAULT '1',
  `path` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='新闻分类表' AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `newsclass`
--

INSERT INTO `newsclass` (`id`, `pid`, `name`, `status`, `is_del`, `path`) VALUES
(1, 0, '公司简介', 1, 1, '0'),
(2, 1, '公司文化', 1, 1, '0-1'),
(3, 1, '公司介绍', 1, 1, '0-1'),
(4, 0, '活动中心', 1, 1, '0'),
(5, 4, '寒假特训班', 1, 1, '0-4'),
(6, 5, '寒假特训班-小班', 1, 1, '0-4-5'),
(7, 5, '寒假特训班-大班', 1, 1, '0-4-5'),
(8, 6, '寒假特训班-小班-加1', 1, 1, '0-4-5-6');

-- --------------------------------------------------------

--
-- 表的结构 `news_detail`
--

DROP TABLE IF EXISTS `news_detail`;
CREATE TABLE IF NOT EXISTS `news_detail` (
  `news_id` int(255) NOT NULL COMMENT '新闻id',
  `news_detail` text NOT NULL COMMENT '新闻详情',
  `is_del` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否删除',
  PRIMARY KEY (`news_id`),
  FULLTEXT KEY `news_detail` (`news_detail`),
  FULLTEXT KEY `news_detail_2` (`news_detail`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='新闻详情';

--
-- 转存表中的数据 `news_detail`
--


-- --------------------------------------------------------

--
-- 表的结构 `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `chname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `sh` int(2) NOT NULL DEFAULT '0',
  `is_del` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否删除',
  `mod_ids` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '模块权限',
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `name`, `chname`, `password`, `status`, `sh`, `is_del`, `mod_ids`, `last_login`) VALUES
(1, '123', '123', '', 1, 0, 1, '2,1', '0000-00-00 00:00:00'),
(2, 'youxu', '尤旭', 'e74d7ce9a9f35be0d0ac073d0e1e0a41', 1, 0, 1, '4,3,2,1', '2012-12-12 21:47:57');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
